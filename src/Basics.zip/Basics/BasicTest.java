package Basics;


import java.util.Arrays;

public class BasicTest {
    public static void main(String[]args){
       Basic numbers = new Basic();
//       Integer num = numbers.printAllNumbers(255);
//       System.out.println(num);
//
//        Integer oddNumbers = numbers.printOddNumbers(255);
//        System.out.println(oddNumbers);
//
//        Integer sumNumbers = numbers.printSum(255);
//        System.out.println(sumNumbers);
//
//        int[] arr = {1,4,55,9,5};
//       numbers.iterateArray(arr);
//
//        int[] negativeArray = {-1,-2,-3,-4,-5};
//        int[] positiveArray = {12,8,9,18,25};
//        int[] mixArray = {0,-5,15,8,-3,5};
//
//        System.out.println(numbers.findMax(negativeArray));
//        System.out.println(numbers.findMax(positiveArray));
//        System.out.println(numbers.findMax(mixArray));

//        int [] average = {10,2,3};
//        int[] complicatedAverage = {1,-3,0,18};
//        numbers.getAverage(average);
//        numbers.getAverage(complicatedAverage);
//
//        numbers.oddNumbersArray();
//
//        int y = 3;
//        int [] array = {2, 3, 5, 7};
//        int count = numbers.greaterThanValue(array, y);
//        System.out.println(count);
//
//        int [] square = {2, 3, 9, -2};
//        numbers.squareValues(square);

//        int[]x = {1,-5,10,-2};
//        numbers.eliminateNegativeNumbers(x);

//        int [] a = {1,5,10,-2};
//        numbers.minMaxAvg(a);

        int []  shiftedArray = {1,5,10,7,-2};
        numbers.shiftingValues(shiftedArray);

    }
}

