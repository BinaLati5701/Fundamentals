package PuzzleJava;

public class PuzzleJavaTest {
    public static void main(String[] args){
        PuzzleJava puzzle = new PuzzleJava();
//        puzzle.arraySum();
//        puzzle.personArray();
//        puzzle.alphaArray();
//        puzzle.randomInteger();
        puzzle.randomString();
    }
}
