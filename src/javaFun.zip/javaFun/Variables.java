package javaFun;

public class Variables {

        public static void main(String[] args){
            int ourInt; // we can declare a variable without setting its value
            ourInt = 400; // we can assign a value to the variable later in our code
            double pi = 3.14159265; // we can also declare and assign on the same line
            boolean bool = true;
            char singleCharacter = 'A';

            String multipleCharacters = "ABC";
        }

}
