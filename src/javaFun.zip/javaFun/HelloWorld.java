package javaFun;

public class HelloWorld {
    public static void main(String[] args){
        System.out.println("Hello World");

        String name = "Coding Dojo";
        int x = 100;
        String city = "Burbank";
        String state = "CA";

        System.out.println("My name is " + name);
        System.out.println("I am " + x + " years old");
        System.out.println("My hometown is " + city + "," +  state);
    }
}
