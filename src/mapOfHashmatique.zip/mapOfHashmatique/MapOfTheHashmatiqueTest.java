package mapOfHashmatique;

public class MapOfTheHashmatiqueTest {
    public static void  main(String[]args) {
        MapOfTheHashmatique songs = new MapOfTheHashmatique();
        songs.trackList();
    }

}
